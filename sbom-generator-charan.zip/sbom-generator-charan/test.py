import subprocess

# # Example Bash command
# bash_command = 'pip freeze > requirements.txt'


# # Execute the Bash command
# result = subprocess.run(bash_command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

# # Print the result
# print("Return Code:", result.returncode)
# print("Standard Output:")
# print(result.stdout)
# print("Standard Error:")
# print(result.stderr)
import shlex

user_input = input("Enter a command: ")
escaped_input = shlex.quote(user_input)

bash_command = f"echo {escaped_input}"
result = subprocess.run(bash_command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

print("Return Code:", result.returncode)
print("Standard Output:")
print(result.stdout)
print("Standard Error:")
print(result.stderr)